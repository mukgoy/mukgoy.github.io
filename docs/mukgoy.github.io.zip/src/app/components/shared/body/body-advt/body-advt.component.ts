import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body-advt',
  templateUrl: './body-advt.component.html',
  styleUrls: ['./body-advt.component.scss']
})
export class BodyAdvtComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
