import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body-content',
  templateUrl: './body-content.component.html',
  styleUrls: ['./body-content.component.scss']
})
export class BodyContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  name  = "mukesh"

}
