import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body-main',
  templateUrl: './body-main.component.html',
  styleUrls: ['./body-main.component.scss']
})
export class BodyMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
